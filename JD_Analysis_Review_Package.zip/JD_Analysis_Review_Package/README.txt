JD Analysis: Review Package
==============================================

This package contains everything needed to review the QLD Mining Supervisor JD analysis.

Suggested review order:

1. Report.docx
   The main findings document. Read this first for the overall analysis.

2. JD Collation (scope and duplicates).xlsx
   Colour-coded spreadsheet showing every source file (97 in total) and
   whether it was kept (in-scope), excluded (out-of-scope), treated as a
   duplicate, or was a broken/empty file. Rows are grouped by status:
     IN SCOPE      57 unique JDs included in the analysis
     DUPLICATE     23 redundant scrapes of in-scope JDs
     OUT OF SCOPE  15 excluded JDs (operator-level, interstate, etc.)
     BROKEN        2 empty failed scrapes
   The "Duplicate group" column is only filled in for files that have an
   actual duplicate relationship (16 groups total).

3. All JDs (organised)/
   The 97 source documents, sorted into four sub-folders that exactly
   match the spreadsheet groupings:
     in-scope/      57 JDs used in the analysis
     out-of-scope/  15 JDs excluded
     duplicates/    23 redundant scrapes
     broken/        2 empty failed scrapes
   Files with a [date] prefix are disambiguated case-insensitive duplicates.

4. Coding Sheet.xlsx
   The full coding output — 789 rows, one per (JD, category, code, evidence).
   Open in Excel and use the filter dropdowns on the header row to slice
   by sector, role type, category, code, etc.

   Three tabs:
     Tab 1 "Coding Sheet"  Each row is colour-tagged by category:
                             purple = DUTY
                             green  = DISPOSITION
                             gold   = QUALIFICATIONS
                             teal   = KNOWLEDGE
                             red    = EXPERIENCE
                             dark purple = STATUTORY POSITION
                           Required column has a subtle highlight:
                             light green  = required
                             light yellow = desirable
                             light grey   = not specified
     Tab 2 "Codebook"      All 87 codes with full labels (filterable).
     Tab 3 "Frequencies"   Every code ranked by JD count + percentage.

5. Codebook.docx
   Word version of the codebook for offline reading.

If anything looks wrong, please flag the specific JD filename and
code/row so it can be revisited.
